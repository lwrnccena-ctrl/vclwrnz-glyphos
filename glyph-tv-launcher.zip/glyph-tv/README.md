# Glyph TV Launcher

A dot-matrix Android TV launcher (Kotlin + Jetpack Compose), recreated from the
"Glyph" desktop shell video: dotted clock, round widget cards, status rail,
circular-icon app drawer, big-type section menu, halftone wallpaper, idle clock.

## Build on GitHub (no local setup)
1. Create a repo and push this folder to `main`.
2. Open the **Actions** tab, **Build APK** runs automatically (or run it by hand).
3. Download **GlyphTV-release-unsigned** from the run's Artifacts. Tag `v1.0` to also get a GitHub Release.

The workflow downloads Space Mono and Space Grotesk (SIL OFL) for the exact typography.
If that download fails the app uses system fonts.

## Install on the TV
```
adb connect <tv-ip>:5555
adb install -r GlyphTV-release-unsigned.apk   # needs signing first, see below
```
Press Home and choose **Glyph** as the default launcher (or open it from the apps row).

## Controls (D-pad)
| Where | Keys |
|---|---|
| Home | arrows move across the deck, OK launches, Left from the deck or OK on the red ring (or Menu key) opens the menu |
| Deck / drawer | hold OK on an app to pin or unpin it |
| Menu | Up/Down section, OK open, Back close |
| Look | Left/Right wallpaper, Up/Down adjust, OK switch dot size / light |
| Idle | Left/Right minutes, OK preview. Any key wakes it |

## First run
On first launch Glyph shows a SETUP screen with **Set as default**. On Android 10+ this opens the system
"set as default Home app" dialog. On older TVs it opens the Home-app settings. The same action lives
in the System menu as **Set as default**. If your TV hides the chooser, use ADB (optional):
```
adb shell cmd package set-home-activity com.glyph.launcher/.MainActivity
adb shell cmd notification allow_listener com.glyph.launcher/com.glyph.launcher.MediaListener
```
No ADB is needed for normal use. These are only shortcuts for locked-down TVs.

## Notes
- Weather comes from wttr.in (keyless, IP-located). Offline shows `--°`.
- "Now playing" needs notification access: use the GRANT ACCESS button on the card.
- Stats are RAM, disk and uptime (Android blocks per-app CPU/GPU reads).
- Local builds: install Gradle 8.7+ and run `gradle assembleDebug`, or let Android Studio generate the wrapper.

## Unsigned APK
Android refuses to install unsigned APKs. Sign it first, e.g.
```
apksigner sign --ks my.jks GlyphTV-release-unsigned.apk
```
