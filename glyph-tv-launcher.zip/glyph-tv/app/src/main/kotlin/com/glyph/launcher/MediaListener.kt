package com.glyph.launcher

import android.service.notification.NotificationListenerService

/**
 * Empty on purpose: enabling this listener in system settings is what lets the
 * launcher read active media sessions for the "now playing" card.
 */
class MediaListener : NotificationListenerService()
