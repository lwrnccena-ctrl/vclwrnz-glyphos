package com.glyph.launcher

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.os.Bundle
import android.os.SystemClock
import android.view.KeyEvent
import android.view.MotionEvent
import androidx.activity.ComponentActivity
import androidx.activity.compose.BackHandler
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.animation.Crossfade
import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.animation.core.tween
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.BoxWithConstraints
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.runtime.Composable
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableLongStateOf
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.produceState
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.unit.Density
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.withContext

class MainActivity : ComponentActivity() {
    lateinit var prefs: Prefs
    val lastInput = mutableLongStateOf(SystemClock.elapsedRealtime())
    val idleActive = mutableStateOf(false)
    val homeSignal = mutableIntStateOf(0)

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        Fonts.init(this)
        prefs = Prefs(this)
        setContent { GlyphApp(this) }
    }

    override fun onNewIntent(intent: Intent) {
        super.onNewIntent(intent)
        idleActive.value = false
        lastInput.longValue = SystemClock.elapsedRealtime()
        homeSignal.intValue++
    }

    override fun onResume() {
        super.onResume()
        lastInput.longValue = SystemClock.elapsedRealtime()
    }

    override fun onStop() {
        super.onStop()
        idleActive.value = false
    }

    override fun dispatchKeyEvent(event: KeyEvent): Boolean {
        lastInput.longValue = SystemClock.elapsedRealtime()
        if (idleActive.value) {
            if (event.action == KeyEvent.ACTION_DOWN) idleActive.value = false
            return true
        }
        return super.dispatchKeyEvent(event)
    }

    override fun dispatchGenericMotionEvent(ev: MotionEvent): Boolean {
        lastInput.longValue = SystemClock.elapsedRealtime()
        return super.dispatchGenericMotionEvent(ev)
    }

    override fun dispatchTouchEvent(ev: MotionEvent): Boolean {
        lastInput.longValue = SystemClock.elapsedRealtime()
        if (idleActive.value) {
            idleActive.value = false
            return true
        }
        return super.dispatchTouchEvent(ev)
    }
}

@Composable
fun GlyphApp(act: MainActivity) {
    // The UI is laid out on a fixed 1280 x 720 dp canvas and scaled to any TV resolution.
    BoxWithConstraints(Modifier.fillMaxSize().background(G.Bg)) {
        val density = Density(constraints.maxWidth / 1280f, 1f)
        CompositionLocalProvider(LocalDensity provides density) {
            Root(act)
        }
    }
}

@Composable
fun Root(act: MainActivity) {
    val ctx = LocalContext.current
    val prefs = act.prefs
    var screen by remember {
        mutableStateOf(if (!prefs.setupSeen && !isDefaultHome(ctx)) Screen.SETUP else Screen.HOME)
    }

    LaunchedEffect(act.homeSignal.intValue) {
        if (act.homeSignal.intValue != 0 && screen != Screen.SETUP) screen = Screen.HOME
    }

    val roleLauncher = rememberLauncherForActivityResult(ActivityResultContracts.StartActivityForResult()) {
        prefs.markSetupSeen()
        if (screen == Screen.SETUP) screen = Screen.HOME
    }
    val askDefault: () -> Unit = {
        val intent = homeRoleIntent(ctx)
        if (intent != null) {
            try { roleLauncher.launch(intent) } catch (e: Exception) { openHomeFallback(ctx) }
        } else {
            openHomeFallback(ctx)
            prefs.markSetupSeen()
            if (screen == Screen.SETUP) screen = Screen.HOME
        }
    }

    // apps (reload when packages change)
    var reload by remember { mutableIntStateOf(0) }
    DisposableEffect(Unit) {
        val r = object : BroadcastReceiver() {
            override fun onReceive(c: Context?, i: Intent?) { reload++ }
        }
        val f = IntentFilter().apply {
            addAction(Intent.ACTION_PACKAGE_ADDED)
            addAction(Intent.ACTION_PACKAGE_REMOVED)
            addAction(Intent.ACTION_PACKAGE_CHANGED)
            addDataScheme("package")
        }
        ctx.registerReceiver(r, f)
        onDispose { ctx.unregisterReceiver(r) }
    }
    val apps by produceState(emptyList<AppEntry>(), reload) {
        value = withContext(Dispatchers.IO) { loadApps(ctx) }
    }

    var weatherKey by remember { mutableIntStateOf(0) }
    val weather by produceState<Weather?>(null, weatherKey) {
        while (true) {
            val w = fetchWeather()
            if (w != null) { value = w; delay(30 * 60_000L) } else delay(60_000L)
        }
    }

    val hist = remember { mutableStateListOf<Float>() }
    var sys by remember { mutableStateOf(readSys(ctx)) }
    LaunchedEffect(Unit) {
        while (true) {
            val s = withContext(Dispatchers.IO) { readSys(ctx) }
            sys = s
            hist.add(s.ramPct / 100f)
            if (hist.size > 40) hist.removeAt(0)
            delay(2000)
        }
    }

    // Heavy ball on a net: focus moves roll the ball, the dots flow around it, then settle.
    val ball = remember { Ball() }
    val ballTarget = remember { mutableStateOf<Offset?>(null) }
    val ballSetter: (Offset) -> Unit = remember { { o -> ballTarget.value = o } }
    LaunchedEffect(ballTarget.value) {
        ballTarget.value?.let { ball.go(it.x, it.y) }
    }

    // idle mode
    LaunchedEffect(Unit) {
        while (true) {
            delay(5000)
            val m = prefs.idleMin
            if (m > 0 && screen == Screen.HOME && !act.idleActive.value &&
                SystemClock.elapsedRealtime() - act.lastInput.longValue > m * 60_000L
            ) act.idleActive.value = true
        }
    }

    BackHandler(enabled = true) {
        when (screen) {
            Screen.HOME -> {}
            Screen.SETUP -> { prefs.markSetupSeen(); screen = Screen.HOME }
            Screen.MENU, Screen.APPS -> screen = Screen.HOME
            else -> screen = Screen.MENU
        }
    }

    CompositionLocalProvider(LocalBallTarget provides ballSetter) {
    Box(Modifier.fillMaxSize().background(G.Bg)) {
        if (screen == Screen.HOME || screen == Screen.APPS) {
            CompositionLocalProvider(LocalInteractive provides (screen == Screen.HOME && !act.idleActive.value)) {
                Home(apps, prefs, weather, sys, hist, ball, onWeather = { weatherKey++ }, onMenu = { screen = Screen.MENU }, onAllApps = { screen = Screen.APPS })
            }
        }
        Crossfade(targetState = screen, animationSpec = tween(320, easing = FastOutSlowInEasing), label = "screen") { s ->
        when (s) {
            Screen.APPS -> AppDrawer(apps, prefs)
            Screen.MENU -> MenuScreen(prefs) { screen = it }
            Screen.LOOK -> LookScreen(prefs)
            Screen.IDLE -> IdleSettings(prefs) { act.idleActive.value = true }
            Screen.SYSTEM -> SystemScreen(askDefault)
            Screen.SETUP -> SetupScreen(askDefault) { prefs.markSetupSeen(); screen = Screen.HOME }
            Screen.HOME -> {}
        }
        }
        if (act.idleActive.value) IdleClock(prefs, weather)
    }
    }
}
