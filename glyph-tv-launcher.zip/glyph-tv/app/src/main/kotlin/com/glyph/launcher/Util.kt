package com.glyph.launcher

import androidx.compose.animation.animateColorAsState
import androidx.compose.animation.core.Animatable
import androidx.compose.animation.core.Spring
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.spring
import androidx.compose.foundation.border
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Shape
import androidx.compose.ui.unit.dp
import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.animation.core.tween
import androidx.compose.foundation.focusable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.ui.graphics.graphicsLayer
import kotlinx.coroutines.delay
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.runtime.compositionLocalOf
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberUpdatedState
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.composed
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.layout.onGloballyPositioned
import androidx.compose.ui.layout.positionInRoot
import androidx.compose.ui.focus.onFocusChanged
import androidx.compose.ui.input.key.Key
import androidx.compose.ui.input.key.KeyEvent
import androidx.compose.ui.input.key.KeyEventType
import androidx.compose.ui.input.key.key
import androidx.compose.ui.input.key.onKeyEvent
import androidx.compose.ui.input.key.type
import androidx.compose.ui.input.pointer.pointerInput

/** When false (e.g. an overlay is open) tvClickable items stop taking focus. */
val LocalInteractive = compositionLocalOf { true }

/** Focused items report their centre (root px) here so the wallpaper ball can roll to them. */
val LocalBallTarget = compositionLocalOf<((Offset) -> Unit)?> { null }

fun KeyEvent.isOk() = key == Key.DirectionCenter || key == Key.Enter || key == Key.NumPadEnter
fun KeyEvent.down() = type == KeyEventType.KeyDown

/**
 * D-pad friendly click: OK = click, holding OK (auto-repeat) = long press.
 * Also supports touch / mouse taps.
 */
fun Modifier.tvClickable(
    onLong: (() -> Unit)? = null,
    onFocus: (Boolean) -> Unit = {},
    onClick: () -> Unit,
): Modifier = composed {
    val interactive = LocalInteractive.current
    var fired by remember { mutableStateOf(false) }
    val click by rememberUpdatedState(onClick)
    val long by rememberUpdatedState(onLong)
    val focusCb by rememberUpdatedState(onFocus)

    val report = LocalBallTarget.current
    val center = remember { floatArrayOf(0f, 0f) }

    var m: Modifier = this
        .onGloballyPositioned { c ->
            val p = c.positionInRoot()
            center[0] = p.x + c.size.width / 2f
            center[1] = p.y + c.size.height / 2f
        }
        .onFocusChanged {
            focusCb(it.isFocused)
            if (it.isFocused) report?.invoke(Offset(center[0], center[1]))
        }
        .onKeyEvent { ev ->
            if (!ev.isOk()) {
                false
            } else when (ev.type) {
                KeyEventType.KeyDown -> {
                    val rc = ev.nativeKeyEvent.repeatCount
                    if (rc == 0) {
                        fired = false
                    } else if (rc == 1 && long != null) {
                        fired = true
                        long?.invoke()
                    }
                    true
                }
                KeyEventType.KeyUp -> {
                    if (!fired) click()
                    fired = false
                    true
                }
                else -> false
            }
        }
    if (interactive) {
        m = m.focusable().pointerInput(Unit) {
            detectTapGestures(onTap = { click() }, onLongPress = { long?.invoke() })
        }
    }
    m
}

/** Soft fade + rise on first composition, staggered by [delayMs]. Runs on the GPU layer only. */
fun Modifier.enter(delayMs: Int = 0): Modifier = composed {
    val a = remember { Animatable(0f) }
    LaunchedEffect(Unit) {
        delay(delayMs.toLong())
        a.animateTo(1f, tween(650, easing = FastOutSlowInEasing))
    }
    graphicsLayer {
        alpha = a.value
        translationY = (1f - a.value) * 28f * density
    }
}

/** Makes a widget D-pad focusable: white outline + gentle grow on focus, OK runs [onClick]. */
fun Modifier.widget(shape: Shape, onClick: () -> Unit): Modifier = composed {
    var f by remember { mutableStateOf(false) }
    val sc by animateFloatAsState(if (f) 1.04f else 1f, spring(dampingRatio = 0.7f, stiffness = 380f), label = "wsc")
    val line by animateColorAsState(if (f) Color.White else Color.Transparent, androidx.compose.animation.core.tween(180), label = "wline")
    this
        .graphicsLayer { scaleX = sc; scaleY = sc }
        .tvClickable(onFocus = { f = it }, onClick = onClick)
        .border(2.dp, line, shape)
}
