package com.glyph.launcher

import android.content.Intent
import android.provider.Settings
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxScope
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.focusable
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.focus.FocusRequester
import androidx.compose.ui.focus.focusRequester
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.input.key.Key
import androidx.compose.ui.input.key.KeyEvent
import androidx.compose.ui.input.key.key
import androidx.compose.ui.input.key.onKeyEvent
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

/** Full-screen key handler shell used by the settings-style screens. */
@Composable
fun KeyScreen(modifier: Modifier = Modifier, onKey: (KeyEvent) -> Boolean, content: @Composable BoxScope.() -> Unit) {
    val fr = remember { FocusRequester() }
    LaunchedEffect(Unit) {
        try { fr.requestFocus() } catch (e: Exception) { }
    }
    Box(
        modifier.fillMaxSize().background(G.Bg)
            .onKeyEvent { if (it.down()) onKey(it) else false }
            .focusRequester(fr)
            .focusable(),
    ) { content() }
}

@Composable
fun Footer(text: String, modifier: Modifier = Modifier) {
    Mono(text, 9f, G.Dim, modifier.padding(start = 96.dp, bottom = 36.dp), tracking = 1.6f)
}

// ------------------------------------------------------------ menu

@Composable
fun MenuScreen(prefs: Prefs, onPick: (Screen) -> Unit) {
    val items = listOf("HOME" to Screen.HOME, "APPS" to Screen.APPS, "LOOK" to Screen.LOOK, "IDLE" to Screen.IDLE, "SYSTEM" to Screen.SYSTEM)
    var sel by remember { mutableIntStateOf(0) }
    val summary = when (items[sel].second) {
        Screen.HOME -> "DASHBOARD · WIDGETS · DECK"
        Screen.APPS -> "ALL APPS · SEARCH · PIN"
        Screen.LOOK -> "${PRESET_NAMES[prefs.preset]} · DOT ${prefs.dotSize} · LIGHT ${prefs.light}"
        Screen.IDLE -> if (prefs.idleMin == 0) "OFF" else "AFTER ${prefs.idleMin} MIN WITHOUT INPUT"
        else -> "NETWORK · DISPLAY · SOUND"
    }
    KeyScreen(onKey = { k ->
        when {
            k.key == Key.DirectionDown -> { sel = (sel + 1) % items.size; true }
            k.key == Key.DirectionUp -> { sel = (sel + items.size - 1) % items.size; true }
            k.isOk() -> { onPick(items[sel].second); true }
            else -> false
        }
    }) {
        Column(Modifier.padding(start = 96.dp, top = 90.dp)) {
            items.forEachIndexed { i, (name, _) ->
                if (i == sel) {
                    Row(verticalAlignment = Alignment.CenterVertically, modifier = Modifier.padding(vertical = 14.dp)) {
                        Box(Modifier.size(9.dp).clip(CircleShape).background(G.Red))
                        Spacer(Modifier.width(18.dp))
                        DotText(name, 7.dp)
                    }
                } else {
                    Mono(name, 14f, G.Mid, Modifier.padding(start = 27.dp, top = 11.dp, bottom = 11.dp), tracking = 2f)
                }
            }
        }
        Mono(summary, 10f, G.Dim, Modifier.align(Alignment.TopEnd).padding(top = 100.dp, end = 96.dp), tracking = 2f)
        Footer("↑↓ SECTION   ·   OK OPEN   ·   BACK CLOSE", Modifier.align(Alignment.BottomStart))
    }
}

// ------------------------------------------------------------ look

@Composable
fun SmallRing(value: Int, max: Int, label: String, active: Boolean) {
    Column(horizontalAlignment = Alignment.CenterHorizontally) {
        Box(Modifier.size(64.dp), Alignment.Center) {
            Canvas(Modifier.fillMaxSize().padding(2.dp)) {
                val st = Stroke(3.dp.toPx(), cap = StrokeCap.Round)
                drawArc(Color(0xFF333333), 0f, 360f, false, style = st)
                drawArc(if (active) Color.White else G.Mid, -90f, 360f * value / max, false, style = st)
            }
            Sans("$value", 18f, if (active) Color.White else G.Mid, FontWeight.Normal)
        }
        Spacer(Modifier.height(6.dp))
        Mono(label, 8f, if (active) Color.White else G.Dim)
    }
}

@Composable
fun LookScreen(prefs: Prefs) {
    var ring by remember { mutableIntStateOf(0) }
    val n = PRESET_NAMES.size
    KeyScreen(onKey = { k ->
        when {
            k.key == Key.DirectionRight -> { prefs.setPreset((prefs.preset + 1) % n); true }
            k.key == Key.DirectionLeft -> { prefs.setPreset((prefs.preset + n - 1) % n); true }
            k.key == Key.DirectionUp -> {
                if (ring == 0) prefs.setDot((prefs.dotSize + 1).coerceIn(5, 16)) else prefs.setLight((prefs.light + 5).coerceIn(10, 100)); true
            }
            k.key == Key.DirectionDown -> {
                if (ring == 0) prefs.setDot((prefs.dotSize - 1).coerceIn(5, 16)) else prefs.setLight((prefs.light - 5).coerceIn(10, 100)); true
            }
            k.isOk() -> { ring = 1 - ring; true }
            else -> false
        }
    }) {
        Halftone(prefs.preset, prefs.dotSize, (prefs.light + 25).coerceAtMost(100), Modifier.fillMaxSize())
        Column(Modifier.padding(start = 96.dp, top = 56.dp)) {
            Mono("WALLPAPER · PROCEDURAL HALFTONE", 9f)
            Spacer(Modifier.height(10.dp))
            Row(verticalAlignment = Alignment.Bottom) {
                DotText("0${prefs.preset + 1}", 8.dp)
                Spacer(Modifier.width(10.dp))
                Mono("/0$n", 16f, G.Dim)
            }
            Spacer(Modifier.height(10.dp))
            Mono(PRESET_NAMES[prefs.preset], 11f, Color.White, tracking = 3f)
        }
        Row(Modifier.align(Alignment.TopEnd).padding(top = 56.dp, end = 96.dp), horizontalArrangement = Arrangement.spacedBy(18.dp)) {
            SmallRing(prefs.dotSize, 16, "DOT SIZE", ring == 0)
            SmallRing(prefs.light, 100, "LIGHT", ring == 1)
        }
        Row(Modifier.align(Alignment.Center).padding(top = 260.dp), horizontalArrangement = Arrangement.spacedBy(18.dp), verticalAlignment = Alignment.CenterVertically) {
            for (i in 0 until n) {
                val on = i == prefs.preset
                Box(
                    Modifier.size(if (on) 96.dp else 70.dp).clip(CircleShape).background(Color(0xFF0A0A0A))
                        .border(if (on) 2.dp else 1.dp, if (on) Color.White else Color(0xFF333333), CircleShape),
                ) { Halftone(i, 5, 80, Modifier.fillMaxSize()) }
            }
        }
        Footer("←→ BROWSE   ·   ↑↓ ADJUST   ·   OK SWITCH RING   ·   BACK DONE", Modifier.align(Alignment.BottomStart))
    }
}

// ------------------------------------------------------------ idle settings

private val IDLE_OPTIONS = listOf(0, 1, 2, 5, 10, 15, 30)

@Composable
fun IdleSettings(prefs: Prefs, onPreview: () -> Unit) {
    KeyScreen(onKey = { k ->
        val i = IDLE_OPTIONS.indexOf(prefs.idleMin).coerceAtLeast(0)
        when {
            k.key == Key.DirectionRight -> { prefs.setIdle(IDLE_OPTIONS[(i + 1).coerceAtMost(IDLE_OPTIONS.size - 1)]); true }
            k.key == Key.DirectionLeft -> { prefs.setIdle(IDLE_OPTIONS[(i - 1).coerceAtLeast(0)]); true }
            k.isOk() -> { onPreview(); true }
            else -> false
        }
    }) {
        Column(Modifier.padding(start = 96.dp, top = 90.dp)) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Box(Modifier.size(9.dp).clip(CircleShape).background(G.Red))
                Spacer(Modifier.width(18.dp))
                DotText("IDLE", 7.dp)
            }
            Spacer(Modifier.height(60.dp))
            Mono("IDLE · MINUTES WITHOUT INPUT · APPROX", 9f)
            Spacer(Modifier.height(14.dp))
            if (prefs.idleMin == 0) DotText("OFF", 12.dp) else DotText(prefs.idleMin.toString(), 12.dp)
            Spacer(Modifier.height(34.dp))
            Canvas(Modifier.width(620.dp).height(12.dp)) {
                for (m in 0..30) {
                    val x = (m + 0.5f) * size.width / 31
                    val lit = m <= prefs.idleMin && prefs.idleMin > 0
                    val big = m in IDLE_OPTIONS
                    drawCircle(
                        if (lit) Color.White else Color(0xFF3A3A3A),
                        (if (big) 3.2.dp else 2.dp).toPx(),
                        Offset(x, size.height / 2),
                    )
                }
            }
            Spacer(Modifier.height(30.dp))
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                IDLE_OPTIONS.forEach { v ->
                    val on = v == prefs.idleMin
                    Box(
                        Modifier.clip(RoundedCornerShape(50)).background(if (on) Color.White else G.Card2)
                            .padding(horizontal = 16.dp, vertical = 8.dp),
                    ) { Mono(if (v == 0) "OFF" else "$v MIN", 9f, if (on) Color.Black else G.Mid) }
                }
            }
        }
        Footer("←→ ADJUST   ·   OK PREVIEW   ·   BACK DONE", Modifier.align(Alignment.BottomStart))
    }
}

// ------------------------------------------------------------ system

@Composable
fun SystemScreen(onSetDefault: () -> Unit) {
    val ctx = LocalContext.current
    val items = listOf(
        "SET AS DEFAULT" to "",
        "NETWORK" to Settings.ACTION_WIFI_SETTINGS,
        "DISPLAY" to Settings.ACTION_DISPLAY_SETTINGS,
        "SOUND" to Settings.ACTION_SOUND_SETTINGS,
        "BLUETOOTH" to Settings.ACTION_BLUETOOTH_SETTINGS,
        "APPS" to Settings.ACTION_APPLICATION_SETTINGS,
        "MEDIA ACCESS" to "android.settings.ACTION_NOTIFICATION_LISTENER_SETTINGS",
        "ALL SETTINGS" to Settings.ACTION_SETTINGS,
    )
    val fr = remember { FocusRequester() }
    LaunchedEffect(Unit) {
        kotlinx.coroutines.delay(80)
        try { fr.requestFocus() } catch (e: Exception) { }
    }
    Box(Modifier.fillMaxSize().background(G.Bg)) {
        Column(Modifier.padding(start = 96.dp, top = 90.dp)) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Box(Modifier.size(9.dp).clip(CircleShape).background(G.Red))
                Spacer(Modifier.width(18.dp))
                DotText("SYSTEM", 7.dp)
            }
            Spacer(Modifier.height(44.dp))
            items.forEachIndexed { i, (label, action) ->
                var f by remember { mutableStateOf(false) }
                Box(
                    (if (i == 0) Modifier.focusRequester(fr) else Modifier)
                        .width(380.dp).padding(vertical = 3.dp)
                        .clip(RoundedCornerShape(50))
                        .background(if (f) Color.White else Color.Transparent)
                        .tvClickable(onFocus = { f = it }, onClick = {
                            if (action.isEmpty()) { onSetDefault(); return@tvClickable }
                            try {
                                ctx.startActivity(Intent(action).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
                            } catch (e: Exception) {
                                try { ctx.startActivity(Intent(Settings.ACTION_SETTINGS).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)) } catch (e2: Exception) { }
                            }
                        })
                        .padding(horizontal = 22.dp, vertical = 11.dp),
                ) { Mono(label, 12f, if (f) Color.Black else G.Mid, tracking = 2f) }
            }
        }
        Footer("↑↓ SELECT   ·   OK OPEN   ·   BACK DONE", Modifier.align(Alignment.BottomStart))
    }
}

// ------------------------------------------------------------ idle clock

@Composable
fun IdleClock(prefs: Prefs, weather: Weather?) {
    val now by rememberNow()
    val minute = now / 60000L
    val timeStr = SimpleDateFormat("HH:mm", Locale.getDefault()).format(Date(now))
    val dateStr = SimpleDateFormat("EEEE · dd MMMM", Locale.getDefault()).format(Date(now)).uppercase()
    // slow drift to avoid burn-in
    val dx = (((minute * 7) % 41) - 20).toInt()
    val dy = (((minute * 11) % 31) - 15).toInt()
    Box(Modifier.fillMaxSize().background(G.Bg)) {
        Halftone(prefs.preset, prefs.dotSize, prefs.light, Modifier.fillMaxSize())
        Column(
            Modifier.align(Alignment.Center).padding(start = (dx * 2).dp, top = (dy * 2).dp),
            horizontalAlignment = Alignment.CenterHorizontally,
        ) {
            Mono(dateStr, 12f, G.Mid, tracking = 3f)
            Spacer(Modifier.height(34.dp))
            DotText(timeStr, 26.dp)
            Spacer(Modifier.height(34.dp))
            Mono(if (weather != null) "${weather.tempC}° ${weather.desc}" else "GLYPH", 11f, G.Dim, tracking = 3f)
        }
    }
}
