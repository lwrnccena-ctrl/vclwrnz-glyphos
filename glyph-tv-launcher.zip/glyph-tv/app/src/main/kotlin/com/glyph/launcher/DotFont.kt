package com.glyph.launcher

import androidx.compose.foundation.Canvas
import androidx.compose.foundation.layout.size
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp

/** 7-row dot-matrix font (5 columns wide, a few narrower glyphs). */
object DotFont {
    private val raw = mapOf(
        '0' to "01110 10001 10011 10101 11001 10001 01110",
        '1' to "00100 01100 00100 00100 00100 00100 01110",
        '2' to "01110 10001 00001 00010 00100 01000 11111",
        '3' to "11110 00001 00001 01110 00001 00001 11110",
        '4' to "00010 00110 01010 10010 11111 00010 00010",
        '5' to "11111 10000 11110 00001 00001 10001 01110",
        '6' to "00110 01000 10000 11110 10001 10001 01110",
        '7' to "11111 00001 00010 00100 01000 01000 01000",
        '8' to "01110 10001 10001 01110 10001 10001 01110",
        '9' to "01110 10001 10001 01111 00001 00010 01100",
        'A' to "01110 10001 10001 11111 10001 10001 10001",
        'B' to "11110 10001 10001 11110 10001 10001 11110",
        'C' to "01110 10001 10000 10000 10000 10001 01110",
        'D' to "11110 10001 10001 10001 10001 10001 11110",
        'E' to "11111 10000 10000 11110 10000 10000 11111",
        'F' to "11111 10000 10000 11110 10000 10000 10000",
        'G' to "01110 10001 10000 10111 10001 10001 01111",
        'H' to "10001 10001 10001 11111 10001 10001 10001",
        'I' to "01110 00100 00100 00100 00100 00100 01110",
        'J' to "00111 00010 00010 00010 00010 10010 01100",
        'K' to "10001 10010 10100 11000 10100 10010 10001",
        'L' to "10000 10000 10000 10000 10000 10000 11111",
        'M' to "10001 11011 10101 10101 10001 10001 10001",
        'N' to "10001 11001 10101 10011 10001 10001 10001",
        'O' to "01110 10001 10001 10001 10001 10001 01110",
        'P' to "11110 10001 10001 11110 10000 10000 10000",
        'Q' to "01110 10001 10001 10001 10101 10010 01101",
        'R' to "11110 10001 10001 11110 10100 10010 10001",
        'S' to "01111 10000 10000 01110 00001 00001 11110",
        'T' to "11111 00100 00100 00100 00100 00100 00100",
        'U' to "10001 10001 10001 10001 10001 10001 01110",
        'V' to "10001 10001 10001 10001 10001 01010 00100",
        'W' to "10001 10001 10001 10101 10101 11011 10001",
        'X' to "10001 10001 01010 00100 01010 10001 10001",
        'Y' to "10001 10001 01010 00100 00100 00100 00100",
        'Z' to "11111 00001 00010 00100 01000 10000 11111",
        '/' to "00001 00001 00010 00100 01000 10000 10000",
        '-' to "00000 00000 00000 11111 00000 00000 00000",
        '.' to "0 0 0 0 0 0 1",
        '°' to "010 101 010 000 000 000 000",
        // the dagger-style colon from the video: two little plus signs
        ':' to "010 111 010 000 010 111 010",
        ' ' to "000 000 000 000 000 000 000",
    )

    private val glyphs: Map<Char, List<String>> = raw.mapValues { it.value.split(" ") }

    fun glyph(c: Char): List<String> = glyphs[c.uppercaseChar()] ?: glyphs[' ']!!

    fun cols(text: String, tracking: Int = 1): Int {
        if (text.isEmpty()) return 0
        return text.sumOf { glyph(it)[0].length } + tracking * (text.length - 1)
    }
}

@Composable
fun DotText(
    text: String,
    dot: Dp,
    modifier: Modifier = Modifier,
    color: Color = Color.White,
    fill: Float = 0.9f,
    tracking: Int = 1,
    unlit: Color? = null,
) {
    val c = DotFont.cols(text, tracking).coerceAtLeast(1)
    Canvas(modifier.size((dot.value * c).dp, (dot.value * 7).dp)) {
        val d = dot.toPx()
        var x = 0
        text.forEach { ch ->
            val g = DotFont.glyph(ch)
            for (r in 0 until 7) {
                for (col in g[r].indices) {
                    val center = Offset((x + col + 0.5f) * d, (r + 0.5f) * d)
                    if (g[r][col] == '1') {
                        drawCircle(color, d * fill / 2f, center)
                    } else if (unlit != null) {
                        drawCircle(unlit, d * fill * 0.12f, center)
                    }
                }
            }
            x += g[0].length + tracking
        }
    }
}
