package com.glyph.launcher

import android.graphics.Bitmap
import android.graphics.Color as AColor
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.ColorFilter
import androidx.compose.ui.graphics.ColorMatrix
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.DrawScope
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import java.util.Calendar
import java.util.Locale
import kotlin.math.PI
import kotlin.math.cos
import kotlin.math.sin
import kotlin.math.sqrt

val CardShape = RoundedCornerShape(28.dp)
val GrayFilter = ColorFilter.colorMatrix(ColorMatrix().apply { setToSaturation(0f) })

// ------------------------------------------------------------ weather

@Composable
fun CloudIcon(modifier: Modifier = Modifier, bg: Color = G.Card) {
    Canvas(modifier) {
        val s = size.minDimension
        fun shapes(color: Color, grow: Float) {
            drawCircle(color, s * 0.20f + grow, Offset(s * 0.36f, s * 0.52f))
            drawCircle(color, s * 0.26f + grow, Offset(s * 0.58f, s * 0.42f))
            drawRoundRect(
                color,
                Offset(s * 0.14f - grow, s * 0.52f - grow),
                Size(s * 0.72f + 2 * grow, s * 0.24f + 2 * grow),
                CornerRadius(s * 0.12f + grow),
            )
        }
        shapes(G.Mid, s * 0.05f)
        shapes(bg, 0f)
    }
}

@Composable
fun WeatherCard(w: Weather?, modifier: Modifier = Modifier, onClick: () -> Unit = {}) {
    Column(
        modifier.size(136.dp).widget(CircleShape, onClick).clip(CircleShape).background(G.Card),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.Center,
    ) {
        CloudIcon(Modifier.size(38.dp))
        Spacer(Modifier.height(4.dp))
        Sans(if (w != null) "${w.tempC}°" else "--°", 28f, G.Text, FontWeight.Normal)
        Mono(if (w != null) "${w.desc.take(7)} · ${w.minC}°/${w.maxC}°" else "NO DATA", 8f)
    }
}

// ------------------------------------------------------------ calendar

@Composable
fun CalendarCard(cal: Calendar, modifier: Modifier = Modifier, onClick: () -> Unit = {}) {
    val month = cal.getDisplayName(Calendar.MONTH, Calendar.LONG, Locale.getDefault()) ?: ""
    val today = (cal.get(Calendar.DAY_OF_WEEK) + 5) % 7 // Monday = 0
    val letters = listOf("M", "T", "W", "T", "F", "S", "S")
    Column(
        modifier.size(140.dp, 136.dp).widget(CardShape, onClick).clip(CardShape).background(G.Card).padding(16.dp),
        verticalArrangement = Arrangement.SpaceBetween,
    ) {
        Mono(month, 9f)
        DotText(cal.get(Calendar.DAY_OF_MONTH).toString(), 6.dp)
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
            letters.forEachIndexed { i, l ->
                Mono(l, 8f, if (i == today) Color.White else G.Dim, tracking = 0f)
            }
        }
    }
}

// ------------------------------------------------------------ ring

@Composable
fun RingCard(pct: Int, label: String, modifier: Modifier = Modifier, onClick: () -> Unit = {}) {
    Box(modifier.size(136.dp).widget(CircleShape, onClick).clip(CircleShape).background(G.Card), Alignment.Center) {
        Canvas(Modifier.fillMaxSize().padding(8.dp)) {
            val n = 48
            val r = size.minDimension / 2 - 3.dp.toPx()
            val lit = (n * pct.coerceIn(0, 100)) / 100
            for (i in 0 until n) {
                val ang = -PI / 2 + 2 * PI * i / n
                val c = Offset(center.x + (r * cos(ang)).toFloat(), center.y + (r * sin(ang)).toFloat())
                if (i < lit) drawCircle(Color.White, 2.3.dp.toPx(), c)
                else drawCircle(Color(0xFF333333), 1.4.dp.toPx(), c)
            }
        }
        Column(horizontalAlignment = Alignment.CenterHorizontally) {
            DotText(pct.toString(), 4.dp)
            Spacer(Modifier.height(6.dp))
            Mono(label, 8f)
        }
    }
}

// ------------------------------------------------------------ now playing

@Composable
fun ArtDots(art: Bitmap?, key: String, modifier: Modifier = Modifier) {
    val n = 26
    val grid = remember(key) {
        try {
            art?.let { b ->
                val sm = Bitmap.createScaledBitmap(b, n, n, true)
                FloatArray(n * n) { i ->
                    val p = sm.getPixel(i % n, i / n)
                    (0.299f * AColor.red(p) + 0.587f * AColor.green(p) + 0.114f * AColor.blue(p)) / 255f
                }
            }
        } catch (e: Exception) {
            null
        }
    }
    Canvas(modifier) {
        val s = size.minDimension / n
        for (y in 0 until n) for (x in 0 until n) {
            val dx = x - (n - 1) / 2f
            val dy = y - (n - 1) / 2f
            if (sqrt(dx * dx + dy * dy) > n / 2f) continue
            val v = grid?.get(y * n + x) ?: (0.25f + 0.2f * sin(x * 0.9f) * cos(y * 0.9f))
            drawCircle(Color.White.copy(alpha = 0.35f + 0.65f * v), s * 0.5f * (0.15f + 0.85f * v), Offset((x + 0.5f) * s, (y + 0.5f) * s))
        }
    }
}

// Dot-matrix transport icons (7x7), same language as the clock: 0 prev, 1 next, 2 pause, 3 play.
private val ICONS = listOf(
    listOf("1000001", "1000011", "1000111", "1001111", "1000111", "1000011", "1000001"),
    listOf("1000001", "1100001", "1110001", "1111001", "1110001", "1100001", "1000001"),
    List(7) { "0110110" },
    listOf("1000000", "1110000", "1111100", "1111111", "1111100", "1110000", "1000000"),
)

@Composable
fun TransportIcon(kind: Int, color: Color, sz: Dp = 18.dp) {
    Canvas(Modifier.size(sz)) {
        val p = size.minDimension / 7f
        ICONS[kind].forEachIndexed { r, row ->
            row.forEachIndexed { c, ch ->
                if (ch == '1') drawCircle(color, p * 0.44f, Offset((c + 0.5f) * p, (r + 0.5f) * p))
            }
        }
    }
}

@Composable
fun TransportButton(kind: Int, red: Boolean, sz: Dp, onClick: () -> Unit) {
    var f by remember { mutableStateOf(false) }
    Box(
        Modifier
            .size(sz)
            .clip(CircleShape)
            .background(if (red) G.Red else if (f) Color(0xFF333333) else Color.Transparent)
            .border(2.dp, if (f) Color.White else Color.Transparent, CircleShape)
            .tvClickable(onFocus = { f = it }, onClick = onClick),
        Alignment.Center,
    ) { TransportIcon(kind, Color.White) }
}

@Composable
fun NowPlayingCard(np: NowPlaying?, access: Boolean, onGrant: () -> Unit, modifier: Modifier = Modifier) {
    Row(
        modifier.height(150.dp).clip(CardShape).background(G.Card).padding(18.dp),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        ArtDots(np?.art, (np?.title ?: "") + (np?.artist ?: ""), Modifier.size(100.dp))
        Spacer(Modifier.width(18.dp))
        Column(Modifier.fillMaxHeight(), verticalArrangement = Arrangement.Center) {
            if (np != null) {
                Mono("NOW PLAYING · ${np.app}".take(30), 8f)
                Spacer(Modifier.height(6.dp))
                Sans(np.title, 19f, G.Text, FontWeight.Medium, Modifier.width(250.dp))
                Mono(np.artist.take(28), 9f, G.Mid)
                Spacer(Modifier.height(10.dp))
                Canvas(Modifier.width(250.dp).height(4.dp)) {
                    val n = 36
                    val lit = (n * np.progress).toInt()
                    for (i in 0 until n) {
                        drawCircle(
                            if (i <= lit) Color.White else Color(0xFF3A3A3A),
                            if (i <= lit) 1.8.dp.toPx() else 1.3.dp.toPx(),
                            Offset((i + 0.5f) * size.width / n, size.height / 2),
                        )
                    }
                }
                Spacer(Modifier.height(10.dp))
                Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                    TransportButton(0, false, 28.dp) { np.controller.transportControls.skipToPrevious() }
                    TransportButton(if (np.playing) 2 else 3, true, 38.dp) {
                        if (np.playing) np.controller.transportControls.pause() else np.controller.transportControls.play()
                    }
                    TransportButton(1, false, 28.dp) { np.controller.transportControls.skipToNext() }
                }
            } else if (!access) {
                Mono("NOW PLAYING", 8f)
                Spacer(Modifier.height(6.dp))
                Sans("Media access off", 17f, G.Text, FontWeight.Normal)
                Spacer(Modifier.height(12.dp))
                var f by remember { mutableStateOf(false) }
                Box(
                    Modifier.clip(RoundedCornerShape(50)).background(if (f) Color.White else G.Card2)
                        .tvClickable(onFocus = { f = it }, onClick = onGrant)
                        .padding(horizontal = 16.dp, vertical = 8.dp),
                ) { Mono("GRANT ACCESS", 9f, if (f) Color.Black else G.Mid) }
            } else {
                Mono("NOW PLAYING", 8f)
                Spacer(Modifier.height(6.dp))
                Sans("Nothing playing", 17f, G.Dim, FontWeight.Normal)
            }
        }
    }
}

// ------------------------------------------------------------ stats

@Composable
fun StatBlock(label: String, value: String) {
    Column {
        Mono(label, 8f)
        Sans(value, 24f, G.Text, FontWeight.Normal)
    }
}

@Composable
fun SysCard(sys: Sys, hist: List<Float>, modifier: Modifier = Modifier, onClick: () -> Unit = {}) {
    Row(
        modifier.height(150.dp).widget(CardShape, onClick).clip(CardShape).background(G.Card).padding(22.dp),
        horizontalArrangement = Arrangement.spacedBy(28.dp),
    ) {
        Column(verticalArrangement = Arrangement.SpaceBetween, modifier = Modifier.fillMaxHeight()) {
            StatBlock("RAM", "${sys.ramPct}%")
            StatBlock("UP", "${sys.uptimeH}H")
        }
        Column(verticalArrangement = Arrangement.SpaceBetween, modifier = Modifier.fillMaxHeight()) {
            StatBlock("USED", gb(sys.ramUsedGb))
            StatBlock("DISK", "${sys.diskPct}%")
        }
        Column(Modifier.weight(1f).fillMaxHeight()) {
            Mono("RAM · LIVE", 8f)
            Spacer(Modifier.height(14.dp))
            Canvas(Modifier.fillMaxWidth().height(36.dp)) {
                val n = 40
                for (i in 0 until n) {
                    val idx = hist.size - n + i
                    val v = if (idx >= 0 && idx < hist.size) hist[idx] else 0f
                    val y = size.height - 2.dp.toPx() - v * (size.height - 4.dp.toPx())
                    val x = (i + 0.5f) * size.width / n
                    drawCircle(Color(0xFF3A3A3A), 1.2.dp.toPx(), Offset(x, size.height - 2.dp.toPx()))
                    if (idx >= 0) drawCircle(Color.White, 1.6.dp.toPx(), Offset(x, y))
                }
            }
        }
    }
}

/** App icon drawn as a dot-matrix glyph. */
@Composable
fun IconDots(dots: FloatArray?, focused: Boolean, modifier: Modifier = Modifier) {
    Canvas(modifier) {
        val n = ICON_N
        val p = size.minDimension / n
        val ink = if (focused) Color.Black else Color.White
        if (dots == null) {
            drawCircle(ink, p * 3f, Offset(size.width / 2, size.height / 2))
            return@Canvas
        }
        for (y in 0 until n) for (x in 0 until n) {
            val v = dots[y * n + x]
            if (v > 0.02f) {
                drawCircle(ink.copy(alpha = if (focused) 0.5f + 0.5f * v else 0.3f + 0.7f * v), p * 0.47f * (0.2f + 0.8f * v), Offset((x + 0.5f) * p, (y + 0.5f) * p))
            }
        }
    }
}
