package com.glyph.launcher

import androidx.compose.animation.core.Animatable
import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.animation.core.tween
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.itemsIndexed
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.BasicTextField
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.ExperimentalComposeUiApi
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.focus.FocusRequester
import androidx.compose.ui.focus.focusRequester
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.SolidColor
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.input.key.onKeyEvent
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalSoftwareKeyboardController
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

@OptIn(ExperimentalComposeUiApi::class)
@Composable
fun AppDrawer(apps: List<AppEntry>, prefs: Prefs) {
    val ctx = LocalContext.current
    val keyboard = LocalSoftwareKeyboardController.current
    var query by remember { mutableStateOf("") }
    var tab by remember { mutableIntStateOf(0) }
    val tabs = listOf("APPS", "GAMES", "FAVS")
    val appear = remember { Animatable(0f) }
    LaunchedEffect(Unit) { appear.animateTo(1f, tween(380, easing = FastOutSlowInEasing)) }
    val first = remember { FocusRequester() }
    LaunchedEffect(Unit) {
        kotlinx.coroutines.delay(120)
        try { first.requestFocus() } catch (e: Exception) { }
    }
    val favs = prefs.favs(apps)
    val shown = apps.filter {
        (tab == 0 || (tab == 1 && it.isGame) || (tab == 2 && it.pkg in favs)) &&
            it.label.contains(query, ignoreCase = true)
    }

    Box(Modifier.fillMaxSize().background(Color(0xCC000000)), Alignment.Center) {
        Column(
            Modifier.graphicsLayer {
                alpha = appear.value
                val k = 0.92f + 0.08f * appear.value
                scaleX = k; scaleY = k
            }.width(780.dp).height(560.dp).clip(RoundedCornerShape(28.dp)).background(Color(0xFF111111)).padding(22.dp),
        ) {
            Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
                Canvas(Modifier.size(14.dp)) {
                    val s = size.minDimension
                    drawCircle(G.Mid, s * 0.34f, Offset(s * 0.42f, s * 0.42f), style = Stroke(s * 0.1f))
                    drawLine(G.Mid, Offset(s * 0.68f, s * 0.68f), Offset(s * 0.92f, s * 0.92f), s * 0.1f)
                }
                Spacer(Modifier.width(12.dp))
                Box(Modifier.weight(1f)) {
                    if (query.isEmpty()) Mono("Search apps…", 12f, G.Dim)
                    BasicTextField(
                        value = query,
                        onValueChange = { query = it },
                        singleLine = true,
                        textStyle = TextStyle(color = Color.White, fontSize = 13.sp, fontFamily = Fonts.mono),
                        cursorBrush = SolidColor(G.Red),
                        modifier = Modifier.fillMaxWidth().onKeyEvent {
                            if (it.isOk() && it.down()) { keyboard?.show(); true } else false
                        },
                    )
                }
                tabs.forEachIndexed { i, t ->
                    var f by remember { mutableStateOf(false) }
                    val on = i == tab
                    Box(
                        Modifier.padding(start = 6.dp).clip(RoundedCornerShape(50))
                            .background(if (on) Color.White else if (f) Color(0xFF333333) else Color.Transparent)
                            .tvClickable(onFocus = { f = it }, onClick = { tab = i })
                            .padding(horizontal = 14.dp, vertical = 7.dp),
                    ) { Mono(t, 9f, if (on) Color.Black else G.Mid) }
                }
            }
            Spacer(Modifier.height(14.dp))
            LazyVerticalGrid(
                columns = GridCells.Fixed(6),
                modifier = Modifier.weight(1f),
                verticalArrangement = Arrangement.spacedBy(8.dp),
            ) {
                itemsIndexed(shown, key = { _, a -> a.pkg }) { i, app ->
                    AppCell(
                        app, 68.dp, false, app.pkg in favs,
                        modifier = if (i == 0) Modifier.focusRequester(first) else Modifier,
                        onLong = { prefs.toggleFav(app.pkg, apps) },
                        onClick = { launch(ctx, app) },
                    )
                }
            }
            Spacer(Modifier.height(8.dp))
            Mono("OK LAUNCH   ·   HOLD OK PIN TO HOME   ·   BACK CLOSE", 8f)
        }
    }
}
