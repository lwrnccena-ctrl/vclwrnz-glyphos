package com.glyph.launcher

import android.content.Context
import androidx.compose.foundation.text.BasicText
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.Font
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.sp

object G {
    val Bg = Color(0xFF000000)
    val Card = Color(0xFF141414)
    val Card2 = Color(0xFF1B1B1B)
    val Dim = Color(0xFF6E6E6E)
    val Mid = Color(0xFFA0A0A0)
    val Text = Color(0xFFF2F2F2)
    val Red = Color(0xFFD71921)
}

object Fonts {
    var mono: FontFamily = FontFamily.Monospace
    var sans: FontFamily = FontFamily.SansSerif

    fun init(ctx: Context) {
        try {
            val list = ctx.assets.list("fonts")?.toList().orEmpty()
            if ("SpaceMono-Regular.ttf" in list) {
                mono = FontFamily(Font("fonts/SpaceMono-Regular.ttf", ctx.assets))
            }
            val grotesk = list.firstOrNull { it.startsWith("SpaceGrotesk") }
            if (grotesk != null) {
                sans = FontFamily(Font("fonts/$grotesk", ctx.assets))
            }
        } catch (e: Throwable) {
            // keep fallbacks
        }
    }
}

@Composable
fun Mono(
    text: String,
    size: Float = 10f,
    color: Color = G.Dim,
    modifier: Modifier = Modifier,
    tracking: Float = 1.4f,
) {
    BasicText(
        text.uppercase(),
        modifier,
        style = TextStyle(color = color, fontSize = size.sp, fontFamily = Fonts.mono, letterSpacing = tracking.sp),
        maxLines = 1,
        overflow = TextOverflow.Clip,
    )
}

@Composable
fun Sans(
    text: String,
    size: Float,
    color: Color = G.Text,
    weight: FontWeight = FontWeight.Light,
    modifier: Modifier = Modifier,
    maxLines: Int = 1,
) {
    BasicText(
        text,
        modifier,
        style = TextStyle(color = color, fontSize = size.sp, fontFamily = Fonts.sans, fontWeight = weight),
        maxLines = maxLines,
        overflow = TextOverflow.Ellipsis,
    )
}
