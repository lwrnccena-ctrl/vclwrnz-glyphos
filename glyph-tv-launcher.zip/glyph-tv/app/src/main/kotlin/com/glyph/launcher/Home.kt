package com.glyph.launcher

import android.os.Build
import android.provider.Settings
import android.text.format.DateFormat
import androidx.compose.animation.animateColorAsState
import androidx.compose.animation.core.Spring
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.spring
import androidx.compose.animation.core.tween
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.State
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.produceState
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.alpha
import androidx.compose.ui.draw.clip
import androidx.compose.ui.focus.FocusRequester
import androidx.compose.ui.focus.focusRequester
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.input.key.Key
import androidx.compose.ui.input.key.key
import androidx.compose.ui.input.key.onPreviewKeyEvent
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.withContext
import java.text.SimpleDateFormat
import java.util.Calendar
import java.util.Date
import java.util.Locale

enum class Screen { SETUP, HOME, MENU, APPS, LOOK, IDLE, SYSTEM }

@Composable
fun rememberNow(): State<Long> = produceState(System.currentTimeMillis()) {
    while (true) {
        value = System.currentTimeMillis()
        delay(1000L - value % 1000L)
    }
}

// ------------------------------------------------------------ reusable round item

@Composable
fun CircleItem(
    label: String,
    size: Dp,
    mono: Boolean,
    modifier: Modifier = Modifier,
    fav: Boolean = false,
    onLong: (() -> Unit)? = null,
    onClick: () -> Unit,
    content: @Composable (Boolean) -> Unit,
) {
    var f by remember { mutableStateOf(false) }
    val sc by animateFloatAsState(if (f) 1.12f else 1f, spring(dampingRatio = 0.65f, stiffness = 380f), label = "sc")
    val bg by animateColorAsState(if (f) Color.White else G.Card2, tween(200), label = "bg")
    Column(
        modifier.width(size + 24.dp).tvClickable(onLong = onLong, onFocus = { f = it }, onClick = onClick),
        horizontalAlignment = Alignment.CenterHorizontally,
    ) {
        Box(
            Modifier.size(size).graphicsLayer { scaleX = sc; scaleY = sc }.clip(CircleShape).background(bg),
            Alignment.Center,
        ) {
            content(f)
            if (fav) Box(Modifier.align(Alignment.TopEnd).padding(6.dp).size(7.dp).clip(CircleShape).background(G.Red))
        }
        Spacer(Modifier.height(8.dp))
        val c = if (f) Color.White else G.Dim
        if (mono) Mono(label.take(10), 8f, c, tracking = 0.8f) else Sans(label, 11f, c, androidx.compose.ui.text.font.FontWeight.Normal)
    }
}

@Composable
fun AppCell(
    app: AppEntry,
    size: Dp,
    mono: Boolean,
    fav: Boolean,
    modifier: Modifier = Modifier,
    onLong: (() -> Unit)? = null,
    onClick: () -> Unit,
) {
    CircleItem(app.label, size, mono, modifier, fav, onLong, onClick) { focused ->
        IconDots(app.dots, focused, Modifier.size(size * 0.6f))
    }
}

// ------------------------------------------------------------ rail

@Composable
fun RailIcon(kind: Int, color: Color) {
    Canvas(Modifier.size(13.dp)) {
        val s = size.minDimension
        val st = Stroke(s * 0.12f, cap = StrokeCap.Round)
        when (kind) {
            0 -> { // wifi
                for (i in 1..3) {
                    val r = s * 0.27f * i
                    drawArc(color, 225f, 90f, false, Offset(s / 2 - r, s * 0.9f - r), Size(2 * r, 2 * r), style = st)
                }
                drawCircle(color, s * 0.07f, Offset(s / 2, s * 0.88f))
            }
            1 -> { // speaker
                drawRect(color, Offset(s * 0.1f, s * 0.36f), Size(s * 0.22f, s * 0.28f))
                drawArc(color, -50f, 100f, false, Offset(s * 0.3f, s * 0.2f), Size(s * 0.5f, s * 0.6f), style = st)
            }
            2 -> { // bell
                drawArc(color, 180f, 180f, false, Offset(s * 0.22f, s * 0.12f), Size(s * 0.56f, s * 0.6f), style = st)
                drawLine(color, Offset(s * 0.12f, s * 0.78f), Offset(s * 0.88f, s * 0.78f), s * 0.12f, StrokeCap.Round)
                drawCircle(color, s * 0.07f, Offset(s / 2, s * 0.93f))
            }
            else -> drawCircle(color, s * 0.4f, style = st)
        }
    }
}

@Composable
fun Rail(onLogo: () -> Unit, modifier: Modifier = Modifier) {
    Column(
        modifier.width(40.dp).fillMaxHeight().clip(RoundedCornerShape(20.dp)).background(Color(0xFF0E0E0E)).padding(vertical = 16.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
    ) {
        var f by remember { mutableStateOf(false) }
        Box(
            Modifier.size(22.dp).clip(CircleShape)
                .border(1.5.dp, if (f) Color.White else G.Red, CircleShape)
                .tvClickable(onFocus = { f = it }, onClick = onLogo),
            Alignment.Center,
        ) { Box(Modifier.size(5.dp).clip(CircleShape).background(if (f) Color.White else G.Red)) }
        Spacer(Modifier.height(16.dp))
        repeat(3) {
            Box(Modifier.size(3.dp).clip(CircleShape).background(G.Dim))
            Spacer(Modifier.height(7.dp))
        }
        Box(Modifier.width(4.dp).height(22.dp).clip(RoundedCornerShape(2.dp)).background(Color.White))
        Spacer(Modifier.weight(1f))
        listOf(0, 1, 2, 3).forEach {
            RailIcon(it, G.Mid)
            Spacer(Modifier.height(16.dp))
        }
    }
}

// ------------------------------------------------------------ home

@Composable
fun Home(
    apps: List<AppEntry>,
    prefs: Prefs,
    weather: Weather?,
    sys: Sys,
    hist: List<Float>,
    ball: Ball,
    onWeather: () -> Unit,
    onMenu: () -> Unit,
    onAllApps: () -> Unit,
) {
    val ctx = LocalContext.current
    val interactive = LocalInteractive.current
    val now by rememberNow()
    val minute = now / 60000L
    val is24 = remember { DateFormat.is24HourFormat(ctx) }
    val timeStr = remember(minute) { SimpleDateFormat(if (is24) "HH:mm" else "h:mm", Locale.getDefault()).format(Date(now)) }
    val dateStr = remember(minute) { SimpleDateFormat("EEEE · dd MMMM · 'WEEK' ww", Locale.getDefault()).format(Date(now)).uppercase() }
    val cal = remember(minute) { Calendar.getInstance().apply { timeInMillis = now } }
    val hour = cal.get(Calendar.HOUR_OF_DAY)
    val greeting = when {
        hour < 5 -> "Good night,"
        hour < 12 -> "Good morning,"
        hour < 18 -> "Good afternoon,"
        else -> "Good evening,"
    }
    val name = remember {
        (Settings.Global.getString(ctx.contentResolver, "device_name") ?: Build.MODEL ?: "tv").lowercase()
    }
    val np by produceState<NowPlaying?>(null) {
        while (true) {
            value = withContext(Dispatchers.IO) { readNowPlaying(ctx) }
            delay(1000)
        }
    }
    val access = remember(np) { hasMediaAccess(ctx) }

    val favPkgs = prefs.favs(apps)
    val favApps = favPkgs.mapNotNull { p -> apps.find { it.pkg == p } }
    val first = remember { FocusRequester() }
    LaunchedEffect(interactive) {
        if (interactive) {
            delay(80)
            try { first.requestFocus() } catch (e: Exception) { }
        }
    }

    Box(
        Modifier.fillMaxSize().onPreviewKeyEvent {
            if (interactive && it.key == Key.Menu && it.down()) { onMenu(); true } else false
        },
    ) {
        Halftone(prefs.preset, prefs.dotSize, prefs.light, Modifier.fillMaxSize(), ball)

        Rail(onMenu, Modifier.padding(start = 12.dp, top = 12.dp, bottom = 12.dp))

        Column(Modifier.enter(0).padding(start = 124.dp, top = 100.dp)) {
            DotText(timeStr, 21.dp)
            Spacer(Modifier.height(30.dp))
            Mono(dateStr, 10f)
            Spacer(Modifier.height(64.dp))
            Sans(greeting, 32f, G.Text)
            Sans("$name.", 32f, G.Dim)
            Spacer(Modifier.height(14.dp))
            Row(horizontalArrangement = Arrangement.spacedBy(18.dp)) {
                Mono("● ${apps.size} apps", 9f)
                if (weather != null) Mono("▲ ${weather.tempC}° ${weather.desc}".take(24), 9f)
            }
        }

        Column(
            Modifier.align(Alignment.TopEnd).enter(90).padding(top = 96.dp, end = 48.dp).width(440.dp),
            verticalArrangement = Arrangement.spacedBy(14.dp),
        ) {
            Row(horizontalArrangement = Arrangement.spacedBy(14.dp)) {
                WeatherCard(weather, onClick = onWeather)
                CalendarCard(cal, onClick = {
                    try {
                        ctx.startActivity(
                            android.content.Intent(android.content.Intent.ACTION_MAIN)
                                .addCategory(android.content.Intent.CATEGORY_APP_CALENDAR)
                                .addFlags(android.content.Intent.FLAG_ACTIVITY_NEW_TASK),
                        )
                    } catch (e: Exception) { }
                })
                RingCard(sys.ramPct, "RAM · ${gb(sys.ramUsedGb)}", onClick = { openStorage(ctx) })
            }
            NowPlayingCard(np, access, onGrant = {
                try {
                    ctx.startActivity(
                        android.content.Intent("android.settings.ACTION_NOTIFICATION_LISTENER_SETTINGS")
                            .addFlags(android.content.Intent.FLAG_ACTIVITY_NEW_TASK),
                    )
                } catch (e: Exception) {
                    try {
                        ctx.startActivity(android.content.Intent(Settings.ACTION_SETTINGS).addFlags(android.content.Intent.FLAG_ACTIVITY_NEW_TASK))
                    } catch (e2: Exception) { }
                }
            })
            SysCard(sys, hist, onClick = { openStorage(ctx) })
        }

        Row(
            Modifier.align(Alignment.BottomStart).enter(180).padding(start = 112.dp, bottom = 36.dp),
            horizontalArrangement = Arrangement.spacedBy(6.dp),
            verticalAlignment = Alignment.Top,
        ) {
            CircleItem("ALL APPS", 64.dp, true, Modifier.focusRequester(first), onClick = onAllApps) { f ->
                Canvas(Modifier.size(24.dp)) {
                    val s = size.minDimension / 3
                    for (r in 0..2) for (c in 0..2) {
                        drawCircle(if (f) Color.Black else Color.White, s * 0.28f, Offset((c + 0.5f) * s, (r + 0.5f) * s))
                    }
                }
            }
            favApps.forEach { app ->
                AppCell(app, 64.dp, true, false, onLong = { prefs.toggleFav(app.pkg, apps) }, onClick = { launch(ctx, app) })
            }
        }
    }
}

fun openStorage(ctx: android.content.Context) {
    try {
        ctx.startActivity(android.content.Intent(Settings.ACTION_MEMORY_CARD_SETTINGS).addFlags(android.content.Intent.FLAG_ACTIVITY_NEW_TASK))
    } catch (e: Exception) {
        try {
            ctx.startActivity(android.content.Intent(Settings.ACTION_SETTINGS).addFlags(android.content.Intent.FLAG_ACTIVITY_NEW_TASK))
        } catch (e2: Exception) { }
    }
}
