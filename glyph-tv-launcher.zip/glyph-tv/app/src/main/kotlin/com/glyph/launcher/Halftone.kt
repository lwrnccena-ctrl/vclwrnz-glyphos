package com.glyph.launcher

import androidx.compose.foundation.layout.Spacer
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.drawBehind
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.unit.dp
import androidx.compose.animation.core.Animatable
import androidx.compose.animation.core.LinearOutSlowInEasing
import androidx.compose.animation.core.spring
import androidx.compose.animation.core.tween
import kotlinx.coroutines.coroutineScope
import kotlinx.coroutines.launch
import kotlin.math.abs
import kotlin.math.cos
import kotlin.math.exp
import kotlin.math.max
import kotlin.math.min
import kotlin.math.sin
import kotlin.math.sqrt

val PRESET_NAMES = listOf("ORB", "WAVE", "RINGS", "VOID")

private fun field(p: Int, nx: Float, ny: Float, a: Float): Float {
    return when (p) {
        0 -> {
            val dx = (nx - 0.88f) * a
            val dy = ny - 1.0f
            val d = sqrt(dx * dx + dy * dy)
            val r = 0.62f
            if (d > r) 0f
            else ((r - d) / (r * 0.55f)).coerceIn(0f, 1f) * (0.8f + 0.2f * sin(nx * 53f) * cos(ny * 47f))
        }
        1 -> (0.5f + 0.5f * sin(nx * 7f * a + ny * 4f)) * ny * ny
        2 -> {
            val dx = (nx - 0.5f) * a
            val dy = ny - 0.5f
            val d = sqrt(dx * dx + dy * dy)
            (0.5f + 0.5f * cos(d * 38f)) * (1f - d * 1.5f).coerceIn(0f, 1f)
        }
        else -> 0f
    }
}

/** One spring-chased copy of the ball position. Lighter springs lag more and form the wake. */
class Follower(val stiff: Float, val damp: Float) {
    val x = Animatable(0f)
    val y = Animatable(0f)
}

/**
 * A heavy ball rolling on a net. It rolls to wherever focus lands (springs with a little
 * overshoot), the dots bunch toward it and swell, ripples run outward, and everything
 * settles flat again. Nothing moves unless [go] is called.
 */
class Ball {
    val fs = listOf(Follower(55f, 0.5f), Follower(30f, 0.6f), Follower(16f, 0.7f))
    val kick = Animatable(0f)
    var ready = false

    suspend fun go(tx: Float, ty: Float) {
        if (!ready) {
            fs.forEach { it.x.snapTo(tx); it.y.snapTo(ty) }
            ready = true
            return
        }
        coroutineScope {
            launch { kick.snapTo(1f); kick.animateTo(0f, tween(2400, easing = LinearOutSlowInEasing)) }
            fs.forEach { f ->
                launch { f.x.animateTo(tx, spring(f.damp, f.stiff)) }
                launch { f.y.animateTo(ty, spring(f.damp, f.stiff)) }
            }
        }
    }

    companion object {
        val W = floatArrayOf(1f, 0.7f, 0.45f)
    }
}

/** Halftone dot wallpaper. dot = pitch in dp, light = 10..100. Pass [ball] for the rolling-ball motion. */
@Composable
fun Halftone(preset: Int, dot: Int, light: Int, modifier: Modifier = Modifier, ball: Ball? = null) {
    Spacer(
        modifier.drawBehind {
            val k = if (ball != null && ball.ready) ball.kick.value else 0f
            val live = k > 0.002f
            if (preset == 3 && !live) return@drawBehind
            val step = dot.dp.toPx()
            val w = size.width
            val h = size.height
            val a = w / h
            val cols = (w / step).toInt() + 1
            val rows = (h / step).toInt() + 1
            val base = 0.10f + 0.55f * (light / 100f)
            val rad = 170.dp.toPx()
            val pull = 46.dp.toPx() * k
            val ripLen = 22.dp.toPx()
            val fx = FloatArray(3)
            val fy = FloatArray(3)
            if (live && ball != null) {
                for (i in 0..2) { fx[i] = ball.fs[i].x.value; fy[i] = ball.fs[i].y.value }
            }
            for (r in 0 until rows) {
                for (c in 0 until cols) {
                    val x = c * step + step / 2
                    val y = r * step + step / 2
                    val v = if (preset == 3) 0f else field(preset, x / w, y / h, a)
                    var px = x
                    var py = y
                    var g = 0f
                    var rip = 0f
                    if (live) {
                        for (i in 0..2) {
                            val dx = fx[i] - x
                            val dy = fy[i] - y
                            if (abs(dx) > 2 * rad || abs(dy) > 2 * rad) continue
                            val d2 = dx * dx + dy * dy
                            val gi = exp(-d2 / (rad * rad)) * Ball.W[i]
                            if (gi < 0.01f) continue
                            val d = sqrt(d2).coerceAtLeast(1f)
                            val df = pull * gi * min(1f, d / (0.4f * rad))
                            px += dx / d * df
                            py += dy / d * df
                            g += gi
                        }
                        val ex = fx[0] - x
                        val ey = fy[0] - y
                        val e2 = ex * ex + ey * ey
                        rip = exp(-e2 / (rad * rad * 1.4f)) * k * sin(sqrt(e2) / ripLen - (1f - k) * 18f)
                    }
                    g = min(1f, g) * k
                    val vv = max(v, 0.65f * g)
                    if (vv > 0.04f) {
                        drawCircle(
                            Color.White.copy(alpha = (base * (0.4f + 0.6f * vv) + 0.4f * g).coerceIn(0f, 1f)),
                            step * 0.46f * (0.25f + 0.75f * vv) * (1f + 0.7f * g + 0.35f * rip),
                            Offset(px, py),
                        )
                    }
                }
            }
        },
    )
}
