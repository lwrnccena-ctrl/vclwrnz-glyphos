package com.glyph.launcher

import android.app.role.RoleManager
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.os.Build
import android.provider.Settings
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.focus.FocusRequester
import androidx.compose.ui.focus.focusRequester
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import kotlinx.coroutines.delay

fun isDefaultHome(ctx: Context): Boolean {
    val i = Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_HOME)
    val ri = ctx.packageManager.resolveActivity(i, PackageManager.MATCH_DEFAULT_ONLY)
    return ri?.activityInfo?.packageName == ctx.packageName
}

/** Android 10+ system dialog "Set Glyph as your default Home app?" (null on older / unsupported TVs). */
fun homeRoleIntent(ctx: Context): Intent? {
    if (Build.VERSION.SDK_INT >= 29) {
        val rm = ctx.getSystemService(RoleManager::class.java)
        if (rm != null && rm.isRoleAvailable(RoleManager.ROLE_HOME) && !rm.isRoleHeld(RoleManager.ROLE_HOME)) {
            return rm.createRequestRoleIntent(RoleManager.ROLE_HOME)
        }
    }
    return null
}

/** Older TVs: open the Home-app settings page, or fire a HOME intent so the chooser appears. */
fun openHomeFallback(ctx: Context) {
    try {
        ctx.startActivity(Intent(Settings.ACTION_HOME_SETTINGS).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
    } catch (e: Exception) {
        try {
            ctx.startActivity(Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_HOME).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
        } catch (e2: Exception) { }
    }
}

@Composable
fun SetupScreen(onSet: () -> Unit, onSkip: () -> Unit) {
    val first = remember { FocusRequester() }
    LaunchedEffect(Unit) {
        delay(100)
        try { first.requestFocus() } catch (e: Exception) { }
    }
    Box(Modifier.fillMaxSize().background(G.Bg)) {
        Halftone(0, 9, 45, Modifier.fillMaxSize())
        Column(Modifier.padding(start = 96.dp, top = 120.dp)) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Box(Modifier.size(9.dp).clip(CircleShape).background(G.Red))
                Spacer(Modifier.width(18.dp))
                DotText("SETUP", 7.dp)
            }
            Spacer(Modifier.height(54.dp))
            Mono("FIRST RUN", 9f)
            Spacer(Modifier.height(14.dp))
            Sans("Set Glyph as your home screen.", 34f, G.Text, FontWeight.Light, maxLines = 2, modifier = Modifier.width(560.dp))
            Spacer(Modifier.height(14.dp))
            Sans("Press Home on your remote and Glyph opens instead of the stock launcher.", 15f, G.Dim, FontWeight.Normal, maxLines = 3, modifier = Modifier.width(480.dp))
            Spacer(Modifier.height(40.dp))
            Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                listOf("SET AS DEFAULT" to onSet, "SKIP FOR NOW" to onSkip).forEachIndexed { i, (label, cb) ->
                    var f by remember { mutableStateOf(false) }
                    Box(
                        (if (i == 0) Modifier.focusRequester(first) else Modifier)
                            .clip(RoundedCornerShape(50))
                            .background(if (f) Color.White else G.Card2)
                            .tvClickable(onFocus = { f = it }, onClick = cb)
                            .padding(horizontal = 24.dp, vertical = 13.dp),
                    ) { Mono(label, 11f, if (f) Color.Black else G.Mid, tracking = 2f) }
                }
            }
        }
        Footer("←→ SELECT   ·   OK CONFIRM   ·   BACK SKIP", Modifier.align(Alignment.BottomStart))
    }
}
