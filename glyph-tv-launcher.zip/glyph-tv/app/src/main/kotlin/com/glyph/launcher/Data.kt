package com.glyph.launcher

import android.app.ActivityManager
import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.content.pm.ApplicationInfo
import android.graphics.Bitmap
import android.graphics.Color as AColor
import android.media.MediaMetadata
import android.media.session.MediaController
import android.media.session.MediaSessionManager
import android.media.session.PlaybackState
import android.os.Build
import android.os.Environment
import android.os.StatFs
import android.os.SystemClock
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.compose.ui.graphics.ImageBitmap
import androidx.compose.ui.graphics.asImageBitmap
import androidx.core.app.NotificationManagerCompat
import androidx.core.graphics.drawable.toBitmap
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL
import java.util.Locale

// ---------------------------------------------------------------- apps

data class AppEntry(
    val label: String,
    val pkg: String,
    val intent: Intent,
    val dots: FloatArray?,
    val isGame: Boolean,
)

const val ICON_N = 22

/**
 * Turns an app icon into a 22x22 dot-matrix: the background fades to faint dots and whatever
 * differs from it (the logo) becomes big dots. Values are 0..1 dot sizes, 0 = transparent.
 */
fun iconDots(bmp: Bitmap): FloatArray {
    val n = ICON_N
    val sm = Bitmap.createScaledBitmap(bmp, n, n, true)
    val lum = FloatArray(n * n)
    val alpha = FloatArray(n * n)
    for (i in 0 until n * n) {
        val p = sm.getPixel(i % n, i / n)
        alpha[i] = AColor.alpha(p) / 255f
        lum[i] = (0.299f * AColor.red(p) + 0.587f * AColor.green(p) + 0.114f * AColor.blue(p)) / 255f
    }
    val bg = (lum[0] + lum[n - 1] + lum[n * (n - 1)] + lum[n * n - 1]) / 4f
    var maxDiff = 0.12f
    for (i in 0 until n * n) if (alpha[i] > 0.5f) maxDiff = maxOf(maxDiff, kotlin.math.abs(lum[i] - bg))
    return FloatArray(n * n) { i ->
        if (alpha[i] < 0.15f) 0f
        else (0.14f + 0.86f * (kotlin.math.abs(lum[i] - bg) / maxDiff).coerceIn(0f, 1f)) * alpha[i]
    }
}

fun loadApps(ctx: Context): List<AppEntry> {
    val pm = ctx.packageManager
    val tv = pm.queryIntentActivities(
        Intent(Intent.ACTION_MAIN).addCategory("android.intent.category.LEANBACK_LAUNCHER"), 0,
    )
    val phone = pm.queryIntentActivities(
        Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER), 0,
    )
    return (tv + phone)
        .filter { it.activityInfo.packageName != ctx.packageName }
        .distinctBy { it.activityInfo.packageName }
        .map { ri ->
            val ai = ri.activityInfo
            val icon = try {
                iconDots(ri.loadIcon(pm).toBitmap(96, 96))
            } catch (e: Throwable) {
                null
            }
            val game = Build.VERSION.SDK_INT >= 26 &&
                ai.applicationInfo.category == ApplicationInfo.CATEGORY_GAME
            val intent = Intent(Intent.ACTION_MAIN)
                .setClassName(ai.packageName, ai.name)
                .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_RESET_TASK_IF_NEEDED)
            AppEntry(ri.loadLabel(pm).toString(), ai.packageName, intent, icon, game)
        }
        .sortedBy { it.label.lowercase() }
}

fun launch(ctx: Context, app: AppEntry) {
    try {
        ctx.startActivity(app.intent)
    } catch (e: Exception) {
        // app vanished or not launchable
    }
}

// ---------------------------------------------------------------- prefs

class Prefs(ctx: Context) {
    private val sp = ctx.getSharedPreferences("glyph", Context.MODE_PRIVATE)

    var preset by mutableIntStateOf(sp.getInt("preset", 0))
        private set
    var dotSize by mutableIntStateOf(sp.getInt("dot", 9))
        private set
    var light by mutableIntStateOf(sp.getInt("light", 50))
        private set
    var idleMin by mutableIntStateOf(sp.getInt("idle", 5))
        private set

    var setupSeen by mutableStateOf(sp.getBoolean("setup", false))
        private set

    fun markSetupSeen() { setupSeen = true; sp.edit().putBoolean("setup", true).apply() }

    private var favCustom by mutableStateOf(sp.contains("favs"))
    private val favorites = mutableStateListOf<String>().apply {
        addAll(sp.getString("favs", "")!!.split(",").filter { it.isNotEmpty() })
    }

    fun setPreset(v: Int) { preset = v; sp.edit().putInt("preset", v).apply() }
    fun setDot(v: Int) { dotSize = v; sp.edit().putInt("dot", v).apply() }
    fun setLight(v: Int) { light = v; sp.edit().putInt("light", v).apply() }
    fun setIdle(v: Int) { idleMin = v; sp.edit().putInt("idle", v).apply() }

    fun favs(apps: List<AppEntry>): List<String> =
        if (favCustom) favorites.toList() else apps.take(7).map { it.pkg }

    fun toggleFav(pkg: String, apps: List<AppEntry>) {
        if (!favCustom) {
            favorites.clear()
            favorites.addAll(apps.take(7).map { it.pkg })
            favCustom = true
        }
        if (favorites.contains(pkg)) favorites.remove(pkg) else favorites.add(pkg)
        sp.edit().putString("favs", favorites.joinToString(",")).apply()
    }
}

// ---------------------------------------------------------------- weather

data class Weather(val tempC: Int, val desc: String, val minC: Int, val maxC: Int)

/** Keyless, IP-located weather from wttr.in. Returns null when offline. */
suspend fun fetchWeather(): Weather? = withContext(Dispatchers.IO) {
    try {
        val conn = URL("https://wttr.in/?format=j1").openConnection() as HttpURLConnection
        conn.connectTimeout = 8000
        conn.readTimeout = 8000
        conn.setRequestProperty("User-Agent", "curl/8.0")
        val j = JSONObject(conn.inputStream.bufferedReader().readText())
        val cur = j.getJSONArray("current_condition").getJSONObject(0)
        val day = j.getJSONArray("weather").getJSONObject(0)
        Weather(
            cur.getString("temp_C").toInt(),
            cur.getJSONArray("weatherDesc").getJSONObject(0).getString("value"),
            day.getString("mintempC").toInt(),
            day.getString("maxtempC").toInt(),
        )
    } catch (e: Exception) {
        null
    }
}

// ---------------------------------------------------------------- system stats

data class Sys(val ramUsedGb: Float, val ramPct: Int, val diskPct: Int, val uptimeH: Long)

fun readSys(ctx: Context): Sys {
    val am = ctx.getSystemService(Context.ACTIVITY_SERVICE) as ActivityManager
    val mi = ActivityManager.MemoryInfo()
    am.getMemoryInfo(mi)
    val used = (mi.totalMem - mi.availMem).coerceAtLeast(0L)
    val ramPct = if (mi.totalMem > 0) (used * 100 / mi.totalMem).toInt() else 0
    val disk = try {
        val st = StatFs(Environment.getDataDirectory().path)
        val total = st.blockCountLong * st.blockSizeLong
        val free = st.availableBlocksLong * st.blockSizeLong
        if (total > 0) ((total - free) * 100 / total).toInt() else 0
    } catch (e: Exception) {
        0
    }
    return Sys(used / 1073741824f, ramPct, disk, SystemClock.elapsedRealtime() / 3600000L)
}

fun gb(v: Float): String = String.format(Locale.US, "%.1f", v).replace('.', ',') + "G"

// ---------------------------------------------------------------- media

data class NowPlaying(
    val title: String,
    val artist: String,
    val app: String,
    val art: Bitmap?,
    val playing: Boolean,
    val progress: Float,
    val controller: MediaController,
)

fun hasMediaAccess(ctx: Context): Boolean =
    NotificationManagerCompat.getEnabledListenerPackages(ctx).contains(ctx.packageName)

fun readNowPlaying(ctx: Context): NowPlaying? {
    return try {
        val msm = ctx.getSystemService(Context.MEDIA_SESSION_SERVICE) as MediaSessionManager
        val list = msm.getActiveSessions(ComponentName(ctx, MediaListener::class.java))
        val c = list.firstOrNull { it.playbackState?.state == PlaybackState.STATE_PLAYING }
            ?: list.firstOrNull()
        val md = c?.metadata
        val title = md?.getString(MediaMetadata.METADATA_KEY_TITLE)
        if (c == null || md == null || title == null) {
            null
        } else {
            val st = c.playbackState
            val playing = st?.state == PlaybackState.STATE_PLAYING
            val dur = md.getLong(MediaMetadata.METADATA_KEY_DURATION)
            var pos = st?.position ?: 0L
            if (playing && st != null) {
                pos += ((SystemClock.elapsedRealtime() - st.lastPositionUpdateTime) * st.playbackSpeed).toLong()
            }
            val app = try {
                val pm = ctx.packageManager
                pm.getApplicationLabel(pm.getApplicationInfo(c.packageName, 0)).toString()
            } catch (e: Exception) {
                c.packageName.substringAfterLast('.')
            }
            NowPlaying(
                title,
                md.getString(MediaMetadata.METADATA_KEY_ARTIST) ?: md.getString(MediaMetadata.METADATA_KEY_ALBUM_ARTIST) ?: "",
                app,
                md.getBitmap(MediaMetadata.METADATA_KEY_ALBUM_ART) ?: md.getBitmap(MediaMetadata.METADATA_KEY_ART),
                playing,
                if (dur > 0) (pos.toFloat() / dur).coerceIn(0f, 1f) else 0f,
                c,
            )
        }
    } catch (e: Exception) {
        null
    }
}
